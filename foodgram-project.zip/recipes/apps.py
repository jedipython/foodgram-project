from django.apps import AppConfig


class recipesConfig(AppConfig):
    name = 'recipes'
